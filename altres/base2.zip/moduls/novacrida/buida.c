#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>

#define __NR_newsyscall free_identifier

int main()
{
	int n;

	n = syscall(__NR_newsyscall);
	printf("Retorna %d\n", n);
}

