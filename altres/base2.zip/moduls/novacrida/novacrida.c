/*
 * New system call
 *
 * Copyright (C) 2007 Enric Morancho
 *
 */

#include <linux/module.h>
#include <linux/syscalls.h> 
#include <linux/thread_info.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("New system call");
MODULE_AUTHOR("Enric Morancho");

extern unsigned sys_call_table[];

asmlinkage long sys_newsyscall(void)
{
	printk("Hello world\n");
	return(29);
}

static int __init newsyscall_init(void)
{
}

static void __exit newsyscall_exit(void)
{
}

module_init(newsyscall_init);
module_exit(newsyscall_exit);
