#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include <asm-i386/unistd.h>

#define NAME "/dev/syscalls"

#define error(miss) { fprintf(stderr, "\n\nERROR (line %d): %s\n\n", __LINE__, miss); exit(1); }

#define TESTING(msg) fprintf(stderr, "\n\n%s...", msg);
#define TESTINGOK() fprintf(stderr, "OK\n");

int main()
{
	int fd1, fd2;
	int r, i;
	int num;
	unsigned data, data_ini, data_end;
	int n_read = 0;

	srand(getpid()); /* Init ramdom generation */
	setbuf(stdout, NULL);

	TESTING("Checking open");
		fd1 = open(NAME, O_RDONLY);
		if (fd1 == -1) error("Device must be opened");

		fd2 = open(NAME, O_RDONLY);
		if (fd2 > 0) error("It shouldnt be opened twice");
		if (errno != EBUSY) error("Error code must be EBUSY");

		if (close(fd1) < 0) error("It must be OK");

		fd2 = open(NAME, O_WRONLY);
		if (fd2 > 0) error("It shouldnt be opened O_WRONLY");
		if (errno != EACCES) error("Error code must be EACCES");

		fd2 = open(NAME, O_RDWR);
		if (fd2 > 0) error("It shouldnt be opened O_RDWR");
		if (errno != EACCES) error("Error code must be EACCES");

		fd1 = open(NAME, O_RDONLY);
		if (fd1 == -1) error("Device must be open");
	TESTINGOK();

	TESTING("Checking lseek");
		r = lseek(fd1, 0, SEEK_SET);
		if (r!=0) error("Must be pointing to 0");

		r = lseek(fd1, sizeof(unsigned)+1, SEEK_SET);
		if (r!=-1) error("It shouldnt be able to point to a location non divisible by sizeof(int)");
		if (errno != EINVAL) error("Error code must be EINVAL");

		r = lseek(fd1, -sizeof(unsigned), SEEK_END);
		if (r!=((NR_syscalls-1)*sizeof(unsigned))) error("Incorrect location");

		r = lseek(fd1, -sizeof(unsigned), SEEK_CUR);
		if (r!=((NR_syscalls-2)*sizeof(unsigned))) error("Incorrect location");

		r = lseek(fd1, 0, SEEK_SET);
		if (r!=0) error("Must be pointing to 0");
	TESTINGOK();

	TESTING("Checking read");
		r = read(fd1, &data, sizeof(unsigned)-1);
		if (r>0) error("It shouldnt be able to read an amount non divisible by sizeof(int)");
		if (errno != EINVAL) error("Error code must be EINVAL");

		while(read(fd1, &data, sizeof(unsigned)) > 0)
			n_read++;
		if (n_read != NR_syscalls) error("Inconsistency");
	TESTINGOK();

	/* Get the number of writes's already performed */
	r = lseek(fd1, __NR_write*sizeof(unsigned), SEEK_SET);
	if (r == -1) error("It must be OK");
	if (r != __NR_write*sizeof(unsigned)) error("Incorrect lseek result");

	if (read(fd1, &data_ini, sizeof(unsigned)) != sizeof(unsigned)) error("reading");

	num = rand() % 1024 + 100;
	fd2 = open("/dev/null", O_WRONLY);
	for (i=num; i>0; i--)
		write(fd2, "c", 1);

	/* Get again the number of write's */
	r = lseek(fd1, __NR_write*sizeof(unsigned), SEEK_SET);
	if (r == -1) error("It must be OK");
	if (r != __NR_write*sizeof(unsigned)) error("Incorrect lseek result");

	if (read(fd1, &data_end, sizeof(unsigned)) != sizeof(unsigned)) error("reading");

	/* data_end - data_ini must be num */
	if ((data_end - data_ini) != num) error("Inconsistent result");

	TESTING("Checking ioctl");
	        /* Clearing number of write's */
	        r = ioctl(fd1, F_SETFD, __NR_write);
		if (r == -1) error("It must be OK");

		r = lseek(fd1, __NR_lseek*sizeof(unsigned), SEEK_SET);
		if (r == -1) error("It must be OK");
		if (read(fd1, &data_end, sizeof(unsigned)) != sizeof(unsigned)) error("reading");
		if (data_end == 0) error("Must be greater than zero");

		r = lseek(fd1, __NR_write*sizeof(unsigned), SEEK_SET);
		if (r == -1) error("It must be OK");
		if (read(fd1, &data_end, sizeof(unsigned)) != sizeof(unsigned)) error("reading");
		if (data_end != 0) error("After clearing __NR_write, must be zero");

		/* Changing owner */
		r = ioctl(fd1, F_SETOWN, -1);
		if (r>0) error("It shouldnt be able to deal with this pid");
		if (errno != EINVAL) error("Error code must be EINVAL");

		r = ioctl(fd1, F_SETOWN, getpid());
		if (r == -1) error("It must be able to deal with this pid");
	TESTINGOK();

	if (close(fd1) < 0) error("close must be ok");

	printf("All correct\n");
	return(0);
}
