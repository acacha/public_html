#include <unistd.h>

int main(int argc, char *argv[])
{
	int r;
	r = write(3, (void*) 0xBBBBBBBB, 10);
	r = read(3, (void*) 0xBBBBBBBB, 10);

	return(0);
}
