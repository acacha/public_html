/*
 * /proc example module
 *
 * Copyright (C) 2007 Enric Morancho
 *
 */

#include <linux/module.h>
#include <linux/mm.h>
#include <asm/uaccess.h>	/* copy_from_user */
#include <linux/proc_fs.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("/proc demo");
MODULE_AUTHOR("Enric Morancho (enricm@ac.upc.edu)");

/* /proc interface to the module */

#define PROC_ENTRY "procdemo"	/* File name */

pid_t pid = 0;

/* Read: Shows information about process "pid" */
/* Information is written in memory (starting at address "page") */
static int read_proc(char *page, char **start, off_t off, int count, int *eof,
		     void *data)
{
	struct task_struct *task = NULL;
	unsigned written = 0;

	if (pid) {
		task = find_task_by_pid(pid);
		if (!task)
			return -EINVAL;

		written +=
		    snprintf(page + written, count - written,
			     "Information about process %u\n", pid);
		written +=
		    snprintf(page + written, count - written, " ppid %u\n",
			     task->parent->pid);
		written +=
		    snprintf(page + written, count - written, " uid %u\n",
			     task->parent->uid);
		written +=
		    snprintf(page + written, count - written,
			     " Voluntary context switches %lu\n", task->nvcsw);
		written +=
		    snprintf(page + written, count - written,
			     " Involuntary context switches %lu\n",
			     task->nivcsw);
		written +=
		    snprintf(page + written, count - written,
			     " Page table address %p\n",
			     (task->mm ? task->mm->pgd : NULL));

		return (written);
	}
	return 0;
}

/* Write: captures the pid of the process */
static ssize_t write_proc(struct file *filp, const char __user * buff,
			  unsigned long len, void *data)
{
#define MAX_LEN 7
	char c[MAX_LEN + 1];

	if (len > MAX_LEN)
		return -EINVAL;

	if (copy_from_user(c, buff, len))
		return -EFAULT;

	c[len] = 0;
	if (!sscanf(c, "%d\n", &pid))
		return -EINVAL;

	printk(KERN_INFO "Read pid %d\n", pid);

	return len;
}

/* Register /proc entry for our module */
static int register_proc(void)
{
	struct proc_dir_entry *new_entry;

	new_entry = create_proc_entry(PROC_ENTRY, S_IFREG, &proc_root);
	if (!new_entry)
		return -1;

	new_entry->read_proc = read_proc;
	new_entry->write_proc = write_proc;
	return 0;
}

/* Unregister /proc entry for our module */
static void unregister_proc(void)
{
	remove_proc_entry(PROC_ENTRY, &proc_root);
}

static int __init procdemo_init(void)
{
	if (register_proc() < 0) {
		return (-1);
	}

	printk(KERN_INFO "procdemo: Correctly installed\n Compiled at %s %s\n",
	       __DATE__, __TIME__);
	return (0);
}

static void __exit procdemo_cleanup(void)
{
	unregister_proc();
	printk(KERN_INFO "EXEMPLE: Cleanup successful\n");
}

module_init(procdemo_init);
module_exit(procdemo_cleanup);
