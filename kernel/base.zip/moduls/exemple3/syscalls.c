/*
 * System Call Catching Module
 *
 * Copyright (C) 2007 Enric Morancho
 *
 */

#include <asm/unistd.h>
#include <asm/uaccess.h>
#include <linux/module.h>
#include <linux/proc_fs.h>

#include "init_names.h"

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("System Call Catching");
MODULE_AUTHOR("Enric Morancho");

#pragma pack(1)
struct desc_reg {
	unsigned short limit;
	unsigned long base;
};

struct interrupt_gate {
	unsigned short offset_low;
	unsigned short segment;
	unsigned char type;
	unsigned char dpl;
	unsigned short offset_high;
};

#pragma pack(4)

static struct interrupt_gate *syscall_gate;	/* Pointer to the Syscall Interrupt Gate */
unsigned original_syscall_handler;	/* Original Syscall Handler */
extern void *new_syscall_handler(void);	/* Pointer to the entry point for the new syscall handler (defined in entry.S) */

pid_t traced_pid = 0;		/* Process to be traced ( 0 means all processes) */
unsigned calls[NR_syscalls];	/* Table for accounting syscalls */

/* Code added to the syscall handler */
void do_added_syscall_handler(unsigned syscall_id)
{
	pid_t pid;

	if (syscall_id > NR_syscalls)
		printk(KERN_INFO "Invalid syscall number %d\n", syscall_id);

	/* Trick to obtain pid of current process... thread_info struct is in the bottom of kernel stack */
	pid =
	    ((struct thread_info *)((unsigned long)(&syscall_id) &
				    0xffffe000))->task->pid;

	if (!traced_pid || (pid == traced_pid))
		calls[syscall_id]++;
}

/* /proc interface to the module */
#define PROC_NAME "syscalls"	/* File name */

/* Read: gets statistical information about the called syscalls */
static int read_proc(char *page, char **start, off_t off, int count, int *eof,
		     void *data)
{
	unsigned total = 0, written = 0, i = 0;

	if (traced_pid)
		written +=
		    snprintf(page + written, count - written, "Traced pid %u\n",
			     traced_pid);

#define FORMAT "%4u %s\n"
	for (i = 0; i < NR_syscalls; i++) {
		if (calls[i]) {
			if ((written + strlen(FORMAT) + 1) >= count) {
				return (written);
			}
			written +=
			    snprintf(page + written, count - written, FORMAT,
				     calls[i], syscall_names[i]);
		}
		total += calls[i];
	}
	written +=
	    snprintf(page + written, count - written,
		     "              Total %4u\n", total);

	return written;
}

/* Write: user writes a pid. The module tracks just the syscalls made by this process */
static ssize_t write_proc(struct file *filp, const char __user * buff,
			  unsigned long len, void *data)
{
#define MAX_LEN 9
	char c[MAX_LEN + 1];

	if (len > MAX_LEN)
		return -EINVAL;

	if (copy_from_user(c, buff, len))
		return -EFAULT;

	c[len] = 0;
	if (!sscanf(c, "%d\n", &traced_pid))
		return -EINVAL;

	printk(KERN_INFO "Traced pid %u\n", traced_pid);
	memset(calls, 0, sizeof(calls));
	return len;
}

/* Register /proc entry for our module */
static int register_proc(void)
{
	struct proc_dir_entry *new_entry;

	new_entry = create_proc_entry(PROC_NAME, S_IFREG, &proc_root);
	if (!new_entry)
		return -1;

	new_entry->read_proc = read_proc;
	new_entry->write_proc = write_proc;
	return 0;
}

/* Unregister /proc entry for our module */
static void unregister_proc(void)
{
	remove_proc_entry(PROC_NAME, &proc_root);
}

static void __exit syscall_cleanup(void);

static int __init syscall_init(void)
{
	static struct desc_reg idtr;	/* IDT Register */

	/* Get the base address of the IDT (interrupt vector) */
	__asm__ __volatile__("sidt %0\n"::"m"(idtr));

	/* Gets a pointer to the original syscall interrupt gate (0x80) */
	syscall_gate =
	    (struct interrupt_gate *)(idtr.base +
				      0x80 * sizeof(struct interrupt_gate));

	/* Retrieves the original syscall handler */
	original_syscall_handler =
	    ((syscall_gate->offset_high << 16) | syscall_gate->offset_low);

	/* Disable interrupts */
	local_irq_disable();
	/* Change the syscall handler */
	syscall_gate->offset_low = (unsigned)(new_syscall_handler) & 0xFFFF;
	syscall_gate->offset_high =
	    ((unsigned)(new_syscall_handler) >> 16) & 0xFFFF;
	/* Enable interrupts */
	local_irq_enable();

	printk(KERN_INFO "Old syscall handler at 0x%x\n",
	       original_syscall_handler);
	printk(KERN_INFO "New syscall handler at 0x%p\n", new_syscall_handler);

	if (register_proc() < 0) {
		syscall_cleanup();
		return (-1);
	}
	init_syscall_names();

	printk(KERN_INFO "Correctly installed\n Compiled at %s %s\n", __DATE__,
	       __TIME__);
	return (0);
}

static void __exit syscall_cleanup(void)
{
	/* Restore the syscall handler */
	local_irq_disable();
	syscall_gate->offset_low = original_syscall_handler & 0xFFFF;
	syscall_gate->offset_high = (original_syscall_handler >> 16) & 0xFFFF;
	local_irq_enable();

	unregister_proc();
	printk(KERN_INFO "Cleanup successful\n");
}

module_init(syscall_init);
module_exit(syscall_cleanup);
