/*
 * SendMail.java
 *
 * Created on 6 / abril / 2006, 15:20
 */

package edu.escolatreball.correuelectronic;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 *
 * @author  sergi.tur
 * @version
 */
public class SendMail extends MIDlet {
    public void startApp() {
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
}
