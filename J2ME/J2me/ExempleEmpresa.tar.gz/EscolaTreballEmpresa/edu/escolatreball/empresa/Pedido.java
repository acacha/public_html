package edu.escolatreball.empresa;

public class Pedido {

	private String id;
	
	public int propiedad1Pedido;
	
	public int propiedad2Pedido;
	
	public int propiedad3Pedido;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPropiedad1Pedido() {
		return propiedad1Pedido;
	}

	public void setPropiedad1Pedido(int propiedad1Pedido) {
		this.propiedad1Pedido = propiedad1Pedido;
	}

	public int getPropiedad2Pedido() {
		return propiedad2Pedido;
	}

	public void setPropiedad2Pedido(int propiedad2Pedido) {
		this.propiedad2Pedido = propiedad2Pedido;
	}

	public int getPropiedad3Pedido() {
		return propiedad3Pedido;
	}

	public void setPropiedad3Pedido(int propiedad3Pedido) {
		this.propiedad3Pedido = propiedad3Pedido;
	}
}
