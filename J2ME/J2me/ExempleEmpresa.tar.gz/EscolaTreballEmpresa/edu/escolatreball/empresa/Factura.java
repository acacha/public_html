package edu.escolatreball.empresa;

public class Factura {
	
	public String id;
	
	public int propiedad1Factura;
	
	public int propiedad2Factura;
	
	public int propiedad3Factura;

	public int getPropiedad3Factura() {
		return propiedad3Factura;
	}

	public void setPropiedad3Factura(int propiedad3Factura) {
		this.propiedad3Factura = propiedad3Factura;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPropiedad1Factura() {
		return propiedad1Factura;
	}

	public void setPropiedad1Factura(int propiedad1Factura) {
		this.propiedad1Factura = propiedad1Factura;
	}

	public int getPropiedad2Factura() {
		return propiedad2Factura;
	}

	public void setPropiedad2Factura(int propiedad2Factura) {
		this.propiedad2Factura = propiedad2Factura;
	}

}
