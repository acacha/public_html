package edu.escolatreball.empresa;

import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import org.apache.commons.dbcp.BasicDataSource;

import edu.escolatreball.empresa.logic.database.DataBaseLogic;
import edu.escolatreball.empresa.logic.database.EmpresaDatabaseLogic;


public class Test {
	
	public static void main(String[] args) {
		
		BasicDataSource ds = new BasicDataSource();
		
		//Canviar por el de postgres
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
	    ds.setUsername("username");
	    ds.setPassword("password");
	    ds.setUrl("myhost:1521:mysid"); //Canviar por la que utilizeis
	    
	    //	  Obtener Facturas
	    DataBaseLogic dblogic=null;
	    List facturas=null;
	    try {
	    	dblogic = new EmpresaDatabaseLogic(ds);
	    	facturas = dblogic.getFacturas();
		} catch (SQLException e) {
			// TODO: handle exception
		}
}

}