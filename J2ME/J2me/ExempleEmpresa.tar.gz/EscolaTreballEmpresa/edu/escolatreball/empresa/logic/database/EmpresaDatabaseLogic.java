package edu.escolatreball.empresa.logic.database;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

import edu.escolatreball.empresa.Factura;
import edu.escolatreball.empresa.Pedido;

public class EmpresaDatabaseLogic extends AbstractDatabaseLogic {

	
	public EmpresaDatabaseLogic() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public EmpresaDatabaseLogic(BasicDataSource ds) throws SQLException {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public Factura getFactura(String id) throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement ps = this.getConnection().prepareStatement(
				this.getGetFacturaQuery());
        ps.setString(1,id);
        ResultSet rs = ps.executeQuery();
        
        Factura fact = new Factura();
        
        fact.setId(rs.getString("idFactura"));
        fact.setPropiedad1Factura(rs.getInt("propiedad1Factura"));
        fact.setPropiedad2Factura(rs.getInt("propiedad1Factura1"));
        fact.setPropiedad3Factura(rs.getInt("propiedad1Factura2"));
        
        ps.close();
        rs.close();
		return fact;
	}

	public Pedido getPedido(String id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public List getFacturas() throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement ps = this.getConnection().prepareStatement(
				this.getGetFacturaQuery());
        ResultSet rs = ps.executeQuery();
        Vector facturas = new Vector();
        if (rs.next())  {
        	Factura fact = new Factura();
        	fact.setId(rs.getString("idFactura"));
            fact.setPropiedad1Factura(rs.getInt("propiedad1Factura"));
            fact.setPropiedad2Factura(rs.getInt("propiedad1Factura1"));
            fact.setPropiedad3Factura(rs.getInt("propiedad1Factura2"));
            facturas.add(fact);
        }  
        
        ps.close();
        rs.close();
		return facturas;
	}

	public List getPedidos() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public int insertPedido(Pedido ped) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int insertFactura(Pedido ped) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int modifyFactura(String id, Factura newFactura) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public int modifyPedido(String id, Pedido newFactura) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

}
