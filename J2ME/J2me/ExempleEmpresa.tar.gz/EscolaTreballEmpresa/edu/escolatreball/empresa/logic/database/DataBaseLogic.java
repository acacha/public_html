package edu.escolatreball.empresa.logic.database;

import edu.escolatreball.empresa.Factura;
import edu.escolatreball.empresa.Pedido;

import java.sql.SQLException;

import java.util.List;



public interface DataBaseLogic {

	Factura getFactura (String id) throws SQLException;
	
	Pedido getPedido(String id) throws SQLException;
	
	List getFacturas() throws SQLException;
	
	List getPedidos() throws SQLException;
	
	int insertPedido(Pedido ped) throws SQLException;
	
	int insertFactura(Pedido ped) throws SQLException;
	
	int modifyFactura(String id, Factura newFactura) throws SQLException;
	
	int modifyPedido(String id, Pedido newFactura) throws SQLException;
	
	
}
