package edu.escolatreball.empresa.logic.model;

import java.sql.SQLException;
import java.util.List;

import edu.escolatreball.empresa.Factura;
import edu.escolatreball.empresa.Pedido;

import edu.escolatreball.empresa.logic.database.DataBaseLogic;

public abstract class ModelLogic {
	
	DataBaseLogic ddlogic;
	
	
	public DataBaseLogic getDdlogic() {
		return ddlogic;
	}


	public void setDdlogic(DataBaseLogic ddlogic) {
		this.ddlogic = ddlogic;
	}


	Factura obtenerFactura (String id){
		
		//TODO: Hacer controles del id? entero superior a 0
		
		Factura fact=null;
		
		try {
			fact= this.getDdlogic().getFactura(id);
			
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("Error al obtener la factura");
		}
		
		//otros controles? fact !=null?
		
		return fact;
	}
	
	
	/* Cabeceras del resto de classes .Las comento para que no de error este
	 *  código al compilar
	 *  
	Pedido obtenerPedido(String id);
	
	List obtenerFacturas();
	
	List obtenerPedidos();
	
	int addPedido(Pedido ped);
	
	int addFactura(Pedido ped);
	
	int modifyFactura(String id, Factura newFactura);
	
	int modifyPedido(String id, Pedido newFactura);*/
}
