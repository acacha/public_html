package edu.escolatreball.empresa.logic.database;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import edu.escolatreball.empresa.Factura;
import edu.escolatreball.empresa.Pedido;

import org.apache.commons.dbcp.BasicDataSource;


public abstract class AbstractDatabaseLogic implements DataBaseLogic {
	
	
	/** Default value of getFacturaQuery atribut 
	 * 
	 * Normalmente lo pongo como constantes publicas porque asi se pueden 
	 * consultar en los javadocs.
	 * Fijate que utilizo as nombredeCampo. És un truco muy util porque al
	 * utilizar los resultsets cuando quiera utilizar un campo concreto 
	 * lo utilizare con el nombre del as loquesea i no  con el nombre del campo.
	 * Asi si luego varia el nombre del campo de base de datos no hay que 
	 * cambiar código
	 * */
	public static final String DEFAULT_GET_FACTURA_QUERY = 
		"SELECT `facturas`.`idFactura` as idFactura,"
			+ "`facturas`.`propiedad1Factura` as propiedad1Factura,"
			+ "`facturas`.`propiedad2Factura` as propiedad2Factura,"
			+ "`facturas`.`propiedad3Factura` as propiedad3Factura "
			+ " FROM `facturas` WHERE `facturas`.`idFactura`=?";

	/* TODO: Estas os las dejo a vosotros....... */
	public static final String DEFAULT_GET_PEDIDO_QUERY = "";

	public static final String DEFAULT_GET_PEDIDOS_QUERY = "";

	public static final String DEFAULT_INSERT_PEDIDO_QUERY = "";

	public static final String DEFAULT_INSERT_FACTURA_QUERY = "";

	protected String getPedidoQuery=DEFAULT_GET_PEDIDO_QUERY;

	protected String getPedidosQuery=DEFAULT_GET_PEDIDOS_QUERY;

	protected String getFacturaQuery=DEFAULT_GET_FACTURA_QUERY;

	protected String getFacturasQuery;

	protected String insertPedidoQuery;

	protected String insertFacturaQuery;

	protected String modifyFacturaQuery;

	protected String modifyPedidoQuery;

	protected BasicDataSource datasource;
	
	/** Holds value of property lastInsertIdQuery.     */
    private String lastInsertIdQuery;
    
	 /** Holds value of property Connection.     */
    private Connection connection;    
	
	public AbstractDatabaseLogic() {
		// TODO Auto-generated constructor stub
	}
	
	public AbstractDatabaseLogic(BasicDataSource ds) throws SQLException {
		// TODO Auto-generated constructor stub
		this.setDatasource(ds);
		this.setConnection(this.getDatasource().getConnection());
		//Connect		
	}
	
	
	// FUNCIONES UTILES CON BASES DE DATOS
	
	 /**
     * Close connection.
     */
    public void close() {
        try {
            if (this.getConnection()!=null) 
                if (!this.getConnection().isClosed())  
                    this.getConnection().close();
            
        }
        catch (SQLException sqle) {
            System.out.println("Error");
        }
        finally {
            this.setConnection(null);
            this.setDatasource(null);
        }
    }
    
    /** Execute a Query returning a Resultset.
     * @param strQuery SQL Query to execute.
     * @throws SQLException a SQlExpception error.
     * @return a ResultSet object with query result.
     */
    public ResultSet executeQuery(String strQuery) throws SQLException {
        Statement stm = this.getConnection().createStatement();
        ResultSet rs = stm.executeQuery(strQuery);
        return rs;
    }
    
    /**
     * Execute a SQL query.
     * @param strQuery the SQL query to execute
     * @throws SQLException if any error occurs trying to execute the SQL query
     */    
    public void execute(String strQuery) throws SQLException {
        Statement stm = this.getConnection().createStatement();
        stm.execute(strQuery);
        //stm.close(); Nunca --> Cierra el recordset tambien!!!!!!!!!

    }
    
    /**
     * create a IN SQL String (value1,value2,value3) using a java List of values.
     * @param invalues Java list with values to build the IN SQL.
     * @return a string value with IN SQL.
     */
    public String createInSQL(List invalues){ 
        return this.createInSQL(invalues,false);
    }
    
    /**
     * create a IN SQL String (value1,value2,value3) using a java List of values.
     * @param invalues Java Collection with values to build the IN SQL.
     * @return a string value with IN SQL.
     */
    public String createInSQL(Collection invalues){ 
        return this.createInSQL(invalues,false);
    }
    
    /**
     * create a IN SQL String (value1,value2,value3) using a java List of values.
     * @param invalues Java list with values to build the IN SQL.
     * @return a string value with IN SQL.
     */
    public String createInSQL(List invalues,boolean string){ 
        StringBuffer SqlIn = new StringBuffer("(");
            for (Iterator it=invalues.iterator();it.hasNext(); ) {
                String invalue = (String) it.next();
                if (string) {
                    SqlIn.append("'").append(invalue).append("'");
                }
                else    {
                    SqlIn.append(invalue);
                }
                if (it.hasNext())   
                    SqlIn.append(",");
                else
                    SqlIn.append(")");
            }
        return SqlIn.toString();
    }
    
    public String escapeMysqlStrings  (String str) {
        if (str!=null)  {
            str = str.replace("'","\\'");
            //str = str.replace(""',"\'");
        }         
        return str;
    }
    
    /**
     * create a IN SQL String (value1,value2,value3) using a java List of values.
     * @param invalues Java Collection with values to build the IN SQL.
     * @return a string value with IN SQL.
     */
    public String createInSQL(Collection invalues,boolean string){ 
        StringBuffer SqlIn = new StringBuffer("(");
            for (Iterator it=invalues.iterator();it.hasNext(); ) {
                String invalue = (String) it.next();
                if (string) {
                    SqlIn.append("'").append(invalue).append("'");
                }
                else    {
                    SqlIn.append(invalue);
                }
                
                if (it.hasNext())   
                    SqlIn.append(",");
                else
                    SqlIn.append(")");
            }
        return SqlIn.toString();
    }
    
   

    public String obtainLastInsertId() throws SQLException    {
        PreparedStatement ps = this.getConnection().prepareStatement(
        		this.getLastInsertIdQuery());
        ResultSet rs = ps.executeQuery();
        String lastInsertId = null;
        if (rs.next())  {
            lastInsertId = rs.getString(1);
        }
        rs.close();
        ps.close();
        return lastInsertId;
        
    }
    
    
    // SETTERS I GETTERS
	
	public String getGetFacturaQuery() {
		return getFacturaQuery;
	}

	public void setGetFacturaQuery(String getFacturaQuery) {
		this.getFacturaQuery = getFacturaQuery;
	}

	public String getGetFacturasQuery() {
		return getFacturasQuery;
	}

	public void setGetFacturasQuery(String getFacturasQuery) {
		this.getFacturasQuery = getFacturasQuery;
	}

	public String getGetPedidoQuery() {
		return getPedidoQuery;
	}

	public void setGetPedidoQuery(String getPedidoQuery) {
		this.getPedidoQuery = getPedidoQuery;
	}

	public String getGetPedidosQuery() {
		return getPedidosQuery;
	}

	public void setGetPedidosQuery(String getPedidosQuery) {
		this.getPedidosQuery = getPedidosQuery;
	}

	public String getInsertFacturaQuery() {
		return insertFacturaQuery;
	}

	public void setInsertFacturaQuery(String insertFacturaQuery) {
		this.insertFacturaQuery = insertFacturaQuery;
	}

	public String getInsertPedidoQuery() {
		return insertPedidoQuery;
	}

	public void setInsertPedidoQuery(String insertPedidoQuery) {
		this.insertPedidoQuery = insertPedidoQuery;
	}

	public String getModifyFacturaQuery() {
		return modifyFacturaQuery;
	}

	public void setModifyFacturaQuery(String modifyFacturaQuery) {
		this.modifyFacturaQuery = modifyFacturaQuery;
	}

	public String getModifyPedidoQuery() {
		return modifyPedidoQuery;
	}

	public void setModifyPedidoQuery(String modifyPedidoQuery) {
		this.modifyPedidoQuery = modifyPedidoQuery;
	}

	public BasicDataSource getDatasource() {
		return datasource;
	}

	public void setDatasource(BasicDataSource datasource) {
		this.datasource = datasource;
	}

	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getLastInsertIdQuery() {
		return lastInsertIdQuery;
	}

	public void setLastInsertIdQuery(String lastInsertIdQuery) {
		this.lastInsertIdQuery = lastInsertIdQuery;
	}

}
